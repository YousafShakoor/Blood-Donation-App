import Header from './components/Header';
import LocationSection from './components/LocationSection';
import DonorHistory from './components/DonorHistory';
import ChatBot from './components/ChatBot';
import DonorPrivacy from './components/DonorPrivacy';
import Footer from './components/Footer';


function App() {
  return (
    <div className="App">
      <Header />
      <main>
        <LocationSection />
        <DonorHistory />
        <ChatBot />
        <DonorPrivacy />
      </main>
      <Footer />
    </div>
  );
}

export default App;
