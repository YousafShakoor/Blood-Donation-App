import React, { useState } from 'react';

function DonorPrivacy() {
  const [visibility, setVisibility] = useState(true);

  return (
    <section id="donor-privacy-section">
      <h2>Donor Privacy Controls</h2>
      <label htmlFor="visibility-toggle">Make my profile visible:</label>
      <input
        type="checkbox"
        id="visibility-toggle"
        checked={visibility}
        onChange={() => setVisibility(!visibility)}
      />
      <p id="visibility-status">Currently: {visibility ? 'Visible' : 'Hidden'}</p>
    </section>
  );
}

export default DonorPrivacy;
